import React, { Component } from 'react';
import { connect } from 'react-redux';

class ProductItem extends Component {
    render() {
        const { imgSrc_jpg, name, imgSrc_png, type } = this.props.prod;
        return (
            <div className="card p-1 mb-3" >
                <img
                    src={imgSrc_jpg}
                    alt="clothes"
                    style={{ width: '100%', height: 180 }} />
                <p>{name}</p>
                <button 
                className="btn btn-info" 
                onClick={() => this.props.setModel(imgSrc_png, type)}>Thử</button>
            </div>
        );
    }
}

const mapDispatchToProps = dispatch => {
    return {
        setModel: (img, type) => {
            dispatch({
                type: 'SET_MODEL',
                payload: {
                    img,
                    type
                }
            })

        }
    }
}

export default connect(undefined, mapDispatchToProps)(ProductItem);