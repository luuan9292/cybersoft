import React, { Component , Fragment } from 'react';
import Home from '../Screens/Home';

class Layout extends Component {
    render() {
        return (
            // <Fragment>
            //     <Home />
            // </Fragment>
            <>
                <Home />
            </>
        );
    }
}

export default Layout;