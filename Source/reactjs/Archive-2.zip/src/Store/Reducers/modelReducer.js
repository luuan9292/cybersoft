let initalState = {
    topclothes: '',
    botclothes: '',
    shoes: '',
    handbags: '',
    necklaces: ''
}

const FilterReducer = (state = initalState, action) => {
    switch (action.type) {
        case "SET_MODEL":
            return { ...state, [action.payload.type]: action.payload.img }
        default: return state;
    }

}
export default FilterReducer;